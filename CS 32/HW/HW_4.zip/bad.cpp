void removeBad(list<Movie*>& li)
{
	list<Movie*>::iterator it = li.begin();
	while (it != li.end())
	{
		if ((*it)->rating() < 50)
		{
			destroyedOnes.push_back((*it)->rating());
			it = li.erase(it);
		}
		else
			it++;
	}
}