void removeOdds(vector<int>& v)
{
	for (size_t i = 0; i < v.size(); i++)
		if (v.at(i) % 2 == 1)
		{
			v.erase(v.begin() + i);
			i--;
		}
}