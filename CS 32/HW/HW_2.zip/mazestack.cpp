#include <iostream>
#include <stack>
using namespace std;

class Coord
{
public:
	Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};

bool pathExists(char maze[][10], int sr, int sc, int er, int ec);
// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise

bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
{
	stack<Coord> coordStack;	// Create a stack of coordinates
	Coord point(sr, sc);		
	coordStack.push(point);		// Push the coordinate to the stack
	maze[sr][sc] = '0';			// Set the encountered coordinate to 0

	int row = sr, col = sc;		// Set the initial coordinates

	while (!coordStack.empty())
	{
		point = coordStack.top();	// Store the coordinates 
		row = point.r();
		col = point.c();
		coordStack.pop();			// Remove the last coordinate from the stack

		if (row == er && col == ec)	// If the coordinate is the endpoint, then return true
			return true;

		if (maze[row - 1][col] == '.')		// Move NORTH
		{
			Coord nextCoord(row - 1, col);	// Set the next coordinates
			coordStack.push(nextCoord);		// Push the coordinates
			maze[row - 1][col] = '0';		// Set the new coordinates to 0
		}
		if (maze[row][col - 1] == '.')		// Move WEST
		{
			Coord nextCoord(row, col - 1);	// Set the next coordinates
			coordStack.push(nextCoord);		// Push the coordinates
			maze[row][col - 1] = '0';		// Set the new coordinates to 0
		}
		if (maze[row + 1][col] == '.')		// Move SOUTH
		{
			Coord nextCoord(row + 1, col);	// Set the next coordinates
			coordStack.push(nextCoord);		// Push the coordinates
			maze[row + 1][col] = '0';			// Set the new coordinates to 0
		} 
		if (maze[row][col+1] == '.')		// Move EAST
		{
			Coord nextCoord(row, col + 1);	// Set the next coordinates
			coordStack.push(nextCoord);		// Push the coordinates
			maze[row][col + 1] = '0';		// Set the new coordinates to 0
		}
	}

	return false;	// return false if the maze is unsolvable
}