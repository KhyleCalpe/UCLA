#include <iostream>
#include <string>
#include <stack>
#include <cassert>
using namespace std;

//	---	Auxiliary Function Declarations ---	//

int precedence(char ch);
bool isInfix(string infix);
bool checkChar(char ch);
bool falseStart(char ch);
bool falseEnd(char ch);
bool isOperator(char ch);
bool isOperand(char ch);
string removeSpaces(string infix);
string infixToPostfix(string infix, string& postfix);

//	--- Evaluate --- //

int evaluate(string infix, string& postfix, bool& result);
// Evaluates a boolean expression
//   If infix is a syntactically valid infix boolean expression,
//   then set postfix to the postfix form of that expression, set
//   result to the value of the expression, and return zero.  If
//   infix is not a syntactically valid expression, return 1; in
//   that case, postfix may or may not be changed, but result must
//   be unchanged.

int evaluate(string infix, string& postfix, bool& result)
{
	if (isInfix(infix))
	{
		postfix = infixToPostfix(infix, postfix);	// Set the postfix to the converted infix

		if (postfix.empty())		// If the postfix is empty, no evaluation occurrs
			return 1;
	
		stack<bool> operandStack;	// Initialize a stack of boolean operands

		for (size_t i = 0; i < postfix.size(); i++)
		{
			if (postfix[i] == 'T')			// Push the values of the operands onto the stack
				operandStack.push(true);
			else if (postfix[i] == 'F')
				operandStack.push(false);
			else if (postfix[i] == '!')		// Push the opposite value of an operand due to '!'  
			{
				bool trueVal = !operandStack.top();
				operandStack.pop();
				operandStack.push(trueVal);
			}
			else
			{
				bool operand2 = operandStack.top();
				operandStack.pop();

				if (operandStack.empty())	// If the stack is empty, return 1
					return 1;

				bool operand1 = operandStack.top();
				operandStack.pop();

				if (postfix[i] == '&')		
				{
					if (operand1 && operand2)		// Push true if both operands are true, else push false
						operandStack.push(true);
					else
						operandStack.push(false);
				}
				if (postfix[i] == '|')
				{
					if (operand1 || operand2)		// Push true if either operand is true, else push false
						operandStack.push(true);
					else
						operandStack.push(false);
				}
			}
		}
		result = operandStack.top();
		return 0;
	} 
	return 1;
}

// --- Auxiliary Function Implementations --- //

int precedence(char ch)
{
	switch (ch)
	{
		case '!':
			return 2;
		case '&':
			return 1;
		case '|':
			return 0;
		default:
			return -1;
	}
}

bool isInfix(string infix)
{
	string copy = removeSpaces(infix);	// Create a copy of infix w/o spaces to check for validity 

	for (size_t i = 0; i < copy.size(); i++)
	{
		if (falseStart(copy[0]) || falseEnd(copy[copy.size() - 1]))	// Check if the starting and ending characters are valid
			return false;

		if (checkChar(copy[i]))																				// The only characters valid:
		{
			if (isOperator(copy[i]))																		
			{
				if (copy[i - 1] != ')' && copy[i - 1] != 'T' && copy[i - 1] != 'F' &&						// before an operator is ), T, and F
					copy[i + 1] != 'T' && copy[i + 1] != 'F' && copy[i + 1] != '!' && copy[i + 1] != '(')	// after an operator is T, F, !, (
					return false;
			}
			else if (isOperand(copy[i]))
			{
				if (copy[i + 1] == 'T' || copy[i + 1] == 'F' || copy[i + 1] == '(' || copy[i + 1] == '!')	// after an operand is &, |, and )
					return false;
			}
		}
		else 
			return false;
	}
	return true;
}

bool checkChar(char ch)
{
	switch (ch) 
	{
	case 'T':
	case 'F':
	case '(':
	case ')':
	case '!':
	case '&':
	case '|':
		return true;
	default:
		return false;
	}
	return false;
}

bool falseStart(char ch)
{
	switch (ch)
	{
		case '&':
		case '|':
		case ')':
			return true;
		default:
			return false;
	}
	return false;
}

bool falseEnd(char ch)
{
	switch (ch)
	{
	case '!':
	case '&':
	case '|':
	case '(':
		return true;
	default:
		return false;
	}
	return false;
}

bool isOperator(char ch)
{
	switch (ch)
	{
		case '&':
		case '|':
			return true;
		default:
			return false;
	}
	return false;
}

bool isOperand(char ch)
{
	switch (ch)
	{
	case 'T':
	case 'F':
		return true;
	default:
		return false;
	}
	return false;
}

string removeSpaces(string infix)
{
	string copy = "";							// Create a string variable to store an infix without spaces
	for (size_t i = 0; i < infix.size(); i++)	// Loop through infix and store non-space characters in copy
		if (infix[i] != ' ')
			copy += infix[i];
	return copy;							// return the copy without spaces
}

string infixToPostfix(string infix, string& postfix)
{
	postfix = "";				// Set the postfix to empty
	stack<char> operatorStack;	// Create a stack of operators
	for (size_t i = 0; i < infix.size(); i++)
	{
		switch (infix[i])
		{
			case 'T':
			case 'F':
				postfix += infix[i];					// Append the char in the string if the ch is an operand
				break;
			case '(':						
				operatorStack.push(infix[i]);			// Add to the stack if the element in the string is '('
				break;
			case ')':
				while (operatorStack.top() != '(')		// Until the scope of parentheses is accounted for, append postfix
				{
					postfix += operatorStack.top();
					operatorStack.pop();				// Pop the char added to postfix
				}
				operatorStack.pop();					// Pop the '('
				break;
			case '!':
			case '&':
			case '|':
				while (!operatorStack.empty() && operatorStack.top() != '(' &&		// Append the operand to postfix if the stack
						precedence(infix[i]) <= precedence(operatorStack.top()))	// is not empty or the top is not '(' and the 
				{																	// precedence of the preceding operand is less
					postfix += operatorStack.top();									// than or equal to the precednce of the 
					operatorStack.pop();											// operand
				}
				operatorStack.push(infix[i]);
				break;
			default:
				break;
		}
	}
	while (!operatorStack.empty())
	{
		postfix += operatorStack.top();
		operatorStack.pop();
	}
	return postfix;
}

//	---	MAIN --- //

int main()
{
	string pf;
	bool answer;
	assert(evaluate("T| F", pf, answer) == 0 && pf == "TF|"  &&  answer);
	assert(evaluate("T|", pf, answer) == 1);
	assert(evaluate("F F", pf, answer) == 1);
	assert(evaluate("TF", pf, answer) == 1);
	assert(evaluate("()", pf, answer) == 1);
	assert(evaluate("T(F|T)", pf, answer) == 1);
	assert(evaluate("T(&T)", pf, answer) == 1);
	assert(evaluate("(T&(F|F)", pf, answer) == 1);
	assert(evaluate("", pf, answer) == 1);
	assert(evaluate("F  |  !F & (T&F) ", pf, answer) == 0
		&& pf == "FF!TF&&|" && !answer);
	assert(evaluate(" F  ", pf, answer) == 0 && pf == "F" && !answer);
	assert(evaluate("((T))", pf, answer) == 0 && pf == "T"  &&  answer);
	cout << "Passed all tests" << endl;
}