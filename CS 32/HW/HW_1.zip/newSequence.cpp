#include <iostream>
#include "newSequence.h"

Sequence::Sequence()
	: m_len(0), m_cap(DEFAULT_MAX_ITEMS), m_sqn(new ItemType[m_cap])
{}

Sequence::Sequence(int cap)
{
	if (cap < 0) {
		std::cout << "The sequence cannot have a negative amount of items." << std::endl;
		exit(1);
	} 
	m_len = 0;
	m_cap = cap;
	m_sqn = new ItemType[m_cap];
}

Sequence::~Sequence()
{
	delete [] m_sqn;
}

Sequence::Sequence(const Sequence & other)
{
	m_len = other.m_len;
	m_cap = other.m_cap;
	m_sqn = new ItemType[m_cap];
	for (int i = 0; i < m_cap; i++)
		m_sqn[i] = other.m_sqn[i];
}

Sequence & Sequence::operator=(const Sequence & other)
{
	if (this != &other) {
		Sequence temp(other);
		swap(temp);
	}
	return *this;
}

bool Sequence::empty() const
{
	return (m_len == 0);
}

int Sequence::size() const
{
	return m_len;
}

bool Sequence::insert(int pos, const ItemType & value)
{
	if (size() < DEFAULT_MAX_ITEMS && pos >= 0 && pos <= size()) {	// Check if the array is full and the position is within bounds
		ItemType tempArr[DEFAULT_MAX_ITEMS - 1];					// Create a temporary array
		for (int i = 0; i < DEFAULT_MAX_ITEMS - pos - 1; i++)		// Fill the temporary array
			tempArr[i] = m_sqn[pos + i];
		m_sqn[pos] = value;											// Insert the value into the specified position in the array
		for (int j = 1; j < DEFAULT_MAX_ITEMS - pos - 1; j++)		// Copy the temporary array into the array with pos + 1
			m_sqn[pos + j] = tempArr[j - 1];
		m_len++;													// Increment the array size
		return true;
	}
	return false;
}

int Sequence::insert(const ItemType & value)
{
	int i = 0;

	for (; i < m_cap; i++) {
		if (value <= m_sqn[i] && size() != m_cap)	// Check if the value is less than any element in the array
		{
			insert(i, value);						// Insert the value at the position
			return i;								// Return the position
		}
	}

	if (size() == m_cap)			// Check if the array's cap is reached
		return -1;

	insert(i, value);				// Insert the value at position i

	return i;						// Return position
}

bool Sequence::erase(int pos)
{
	if (pos >= 0 && pos < size()) {				// Check if the position is in the bounds
		for (int i = size() - 1; i >= pos; i--)	// Move the elements of the array to the left by 1
			m_sqn[i - 1] = m_sqn[i];
	}
	return false;								// if unsuccessful, return false
}

int Sequence::remove(const ItemType & value)
{
	int rmvdItms = 0;
	for (int i = 0; i < size(); i++) {
		if (m_sqn[i] == value) {
			erase(i);
			m_len--;
			rmvdItms++;
		}
	}
	return rmvdItms;
}

bool Sequence::get(int pos, ItemType & value) const
{
	if (pos >= 0 && pos < size()) {		// Check if within bounds
		value = m_sqn[pos];				// Copy the element in the position to value
		return true;
	}
	return false;						// If unsuccessful, return false
}

bool Sequence::set(int pos, const ItemType & value)
{
	if (pos >= 0 && pos < size()) {		// Check if the position is within bounds
		m_sqn[pos] = value;				// replace the element in the array with value
		return true;
	}
	return false;						// If unsuccessful, return false
}

int Sequence::find(const ItemType & value) const
{
	for (int i = 0; i < size(); i++) {
		if (m_sqn[i] == value)
			return i;
	}
	return -1;
}

void Sequence::swap(Sequence & other)
{
	ItemType* copy;
	int max, len;
	
	copy = m_sqn;
	m_sqn = other.m_sqn;
	other.m_sqn = copy;

	max = m_cap;
	m_cap = other.m_cap;
	other.m_cap = max;

	len = m_len;
	m_len = other.m_len;
	other.m_len = len;
}