#ifndef NEWSEQUENCE_INCLUDED
#define NEWSEQUENCE_INCLUDED 

using ItemType = unsigned long;

const int DEFAULT_MAX_ITEMS = 200;

class Sequence
{
public:
	// Constructor, Destructor, Copy Constructor, Assignment Operator
	Sequence();
	Sequence(int cap);
	~Sequence();
	Sequence(const Sequence& other);
	Sequence& operator=(const Sequence& other);

	// Accessors
	bool empty() const;
	int size() const;

	// Functions
	bool insert(int pos, const ItemType& value);
	int insert(const ItemType& value);
	bool erase(int pos);
	int remove(const ItemType& value);
	bool get(int pos, ItemType& value) const;
	bool set(int pos, const ItemType& value);
	int find(const ItemType& value) const;
	void swap(Sequence& other);

private:
	int m_len, m_cap;
	ItemType *m_sqn;

};
#endif // NEWSEQUENCE_INCLUDED