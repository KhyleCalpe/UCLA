#include "ScoreList.h"
#include <iostream>
#include <cassert>
using namespace std;

int main() {
	ScoreList sl;
	sl.add(1);
	sl.add(2);
	sl.add(3);
	sl.add(10);
	sl.add(4);
	sl.add(20);
	sl.add(0);
	sl.remove(3);
	sl.dump();
	assert(sl.size() == 6);
	assert(sl.minimum() == 0);
	assert(sl.maximum() == 20);
}