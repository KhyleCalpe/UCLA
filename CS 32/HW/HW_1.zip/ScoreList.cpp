#include <iostream>
#include "ScoreList.h"

ScoreList::ScoreList()
	: m_scoreNum(0)
{}

bool ScoreList::add(unsigned long score)
{
	if (score >= 0 && score <= 100 && size() < DEFAULT_MAX_ITEMS){		// Check if the score is valid and the object is not full 
		m_list.insert(score);				// add the score to the score list
		m_scoreNum++;						// increment the number of scores
		return true;						// return true if the score was added, else return false
	}
	return false;
}

bool ScoreList::remove(unsigned long score)
{
	if (m_list.remove(score) > 0) {			// attempt to remove score from the score list
		m_scoreNum--;						// reduce the number of scores by 1
		return true;						// return true if score was removed, else return false
	}
	return false;
}

int ScoreList::size() const
{
	return m_scoreNum;
}

unsigned long ScoreList::minimum() const
{
	unsigned long min;				

	if (size() == 0) return NO_SCORE;		// return NO_SCORE if the list is empty

	m_list.get(0, min);						// get the first element in the list
	
	return min;
}

unsigned long ScoreList::maximum() const
{
	unsigned long max;

	if (size() == 0) return NO_SCORE;		// return NO_SCORE if the list is empty

	m_list.get(size() - 1, max);			// get the last element in the list

	return max;
}

void ScoreList::dump() const
{
	ItemType var;
	for (int i = 0; i < size(); i++) {
		m_list.get(i, var);
		std::cerr << "value at position " << i << ": " << var << std::endl;
	}
}