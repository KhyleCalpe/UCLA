#include <iostream>
#include "Sequence.h"

Sequence::Sequence()
	: m_len(0)
{}

bool Sequence::empty() const
{
	return (m_len == 0);
}

int Sequence::size() const
{
	return m_len;
}

bool Sequence::insert(int pos, const ItemType & value)
{	
	if (size() < DEFAULT_MAX_ITEMS && pos >= 0 && pos <= size()) {	// Check if the array is full and the position is within bounds
		ItemType tempArr[DEFAULT_MAX_ITEMS - 1];					// Create a temporary array
		for (int i = 0; i < DEFAULT_MAX_ITEMS - pos - 1; i++)		// Fill the temporary array
			tempArr[i] = m_sqn[pos + i];
		m_sqn[pos] = value;											// Insert the value into the specified position in the array
		for (int j = 1; j < DEFAULT_MAX_ITEMS - pos - 1; j++)		// Copy the temporary array into the array with pos + 1
			m_sqn[pos + j] = tempArr[j - 1];
		m_len++;													// Increment the array size
		return true;
	}
	return false;
}

int Sequence::insert(const ItemType & value)
{
	int i = 0;

	for (; i < size(); i++) {		
		if (value <= m_sqn[i])		// Check if the value is less than any element in the array
		{
			insert(i, value);		// Insert the value at the position
			return i;				// Return the position
		}
	}

	if (i > 199)					// Check if the array's cap is reached
		return -1;

	insert(i, value);				// Insert the value at position i
	return i;						// Return position
}

bool Sequence::erase(int pos)
{ 
	if (pos >= 0 && pos < size()) {				// Check if the position is in the bounds
		for (int i = pos; i < size(); i++)		// Move the elements of the array to the left by 1
			m_sqn[i] = m_sqn[i + 1];
	}
	return false;								// if unsuccessful, return false
}	

int Sequence::remove(const ItemType & value)
{
	int rmvdItms = 0;
	for (int i = 0; i < size(); i++) {
		if (m_sqn[i] == value) {
			erase(i);
			m_len--;
			rmvdItms++;
		}
	}
	return rmvdItms;
}

bool Sequence::get(int pos, ItemType & value) const 
{
	if (pos >= 0 && pos < size()) {		// Check if within bounds
		value = m_sqn[pos];				// Copy the element in the position to value
		return true;
	}
	return false;						// If unsuccessful, return false
}

bool Sequence::set(int pos, const ItemType & value)
{
	if (pos >= 0 && pos < size()){		// Check if the position is within bounds
		m_sqn[pos] = value;				// replace the element in the array with value
		return true;
	}
	return false;						// If unsuccessful, return false
}

int Sequence::find(const ItemType & value) const
{
	for (int i = 0; i < size(); i++) {
		if (m_sqn[i] == value)
			return i;
	}
	return -1;
}

void Sequence::swap(Sequence & other)
{
	ItemType copy;
	int max, lenSwitch;
	bool sizeSwitch;

	if (this->size() >= other.size()) {			// check which object has a larger array
		max = this->size();						// assign the largest array size to max
		this->m_len = max;						// ensure that both arrays can exchange by having equal array sizes
		lenSwitch = other.m_len;				// store the shorter array size to switch later
		other.m_len = max;
		sizeSwitch = false;						// check which lengths to switch
	} else {
		max = other.size();
		other.m_len = max;
		lenSwitch = this->m_len;
		this->m_len = max;
		sizeSwitch = true;
	}

	for (int i = 0; i < max; i++)	{			// swap the array elements
		this->get(i, copy);
		this->set(i, other.m_sqn[i]);
		other.set(i, copy);
	}

	if (!sizeSwitch)							// switch the array sizes
		this->m_len = lenSwitch;
	else
		other.m_len = lenSwitch;
}