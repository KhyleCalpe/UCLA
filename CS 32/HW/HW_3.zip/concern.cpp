class Concern	
{
	public:
		Concern(string name) : m_name(name) {};
		virtual ~Concern() {};
		virtual string person() const { return m_name; };
		virtual string description() const = 0;
		virtual bool possibleFelony() const = 0;
	private:
		string m_name;
};

class EthicsMatter : public Concern	
{
	public:
		EthicsMatter(string name) : Concern(name) {};											
		~EthicsMatter() { cout << "Destroying " << person() << "'s " << m_desc << endl; };
		virtual string description() const { return "An " + m_desc; };
		virtual bool possibleFelony() const { return m_possFelony; }
	private:
		string m_desc = "ethics matter";
		bool m_possFelony = false;
};

class HushPayment : public Concern			
{
	public:
		HushPayment(string name, int amount) : Concern(name), m_amount(amount) {};
		~HushPayment() { cout << "Destroying " << person() << "'s " << m_desc << endl; }
		virtual string description() const { return "A $" + to_string(m_amount) + " payment" ; };
		virtual bool possibleFelony() const { return m_possFelony; }
	private:
		int m_amount;
		string m_desc = "hush payment";
		bool m_possFelony = false;
};

class Investigation : public Concern		
{
	public:
		Investigation(string name) : Concern(name) {};
		~Investigation() { cout << "Destroying " << person() << "'s " << m_desc << endl; }
		virtual string description() const { return "An " + m_desc; };
		virtual bool possibleFelony() const { return m_possFelony; };
	private:
		string m_desc = "investigation";
		bool m_possFelony = true;
};

void display(const Concern* c)
{
	cout << c->description() << " involving " << c->person();
	if (c->possibleFelony())
		cout << ", possibly felonious";
	cout << endl;
}